#ifndef C_H__
#define C_H__
class c;
#endif