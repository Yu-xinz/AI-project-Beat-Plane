#ifndef A_H__
#define A_H__
class a;
#endif