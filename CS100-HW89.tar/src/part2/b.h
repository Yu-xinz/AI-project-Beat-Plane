#ifndef B_H__
#define B_H__
class b;
#endif