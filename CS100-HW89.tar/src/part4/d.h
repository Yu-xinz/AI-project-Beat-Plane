#ifndef D_H__
#define D_H__
class d;
#endif